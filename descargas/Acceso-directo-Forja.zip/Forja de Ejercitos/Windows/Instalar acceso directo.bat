@echo off
rem Crea en el Escritorio un acceso directo a la Forja de Ejercitos con su icono.
set "DEST=%LOCALAPPDATA%\ForjaDeEjercitos"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0forja.ico" "%DEST%\forja.ico" >nul
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESK=%%D"
(
echo [InternetShortcut]
echo URL=https://tutancarton.github.io/forja-ejercitos/
echo IconIndex=0
echo IconFile=%DEST%\forja.ico
) > "%DESK%\Forja de Ejercitos.url"
echo.
echo Listo: tienes "Forja de Ejercitos" en el Escritorio.
pause
