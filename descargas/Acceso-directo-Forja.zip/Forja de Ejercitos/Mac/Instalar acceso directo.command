#!/bin/bash
# Crea en el Escritorio un acceso directo a la Forja de Ejercitos con su icono.
cd "$(dirname "$0")"
DESK="$HOME/Desktop"
F="$DESK/Forja de Ejercitos.webloc"
cat > "$F" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>URL</key><string>https://tutancarton.github.io/forja-ejercitos/</string></dict></plist>
PL
osascript -l JavaScript -e "ObjC.import('AppKit'); var img=\$.NSImage.alloc.initWithContentsOfFile('$(pwd)/forja.png'); \$.NSWorkspace.sharedWorkspace.setIconForFileOptions(img, '$F', 0);" >/dev/null 2>&1
echo "Listo: tienes 'Forja de Ejercitos' en el Escritorio."
